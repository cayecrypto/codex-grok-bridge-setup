param(
 [string]$RequestFile,[string]$Prompt,[switch]$GenerateImage,[switch]$Status,[switch]$Cancel,
 [string]$TaskId,[string]$SendFile,[switch]$FetchArtifact,[switch]$EchoArtifact,[string]$ReferenceImage,
 [string]$ArtifactName='response.txt',[string]$DestinationDirectory,
 [string]$OutputFile,[string]$Model,[string]$Effort,[switch]$Capabilities,
 [ValidateRange(0,604800)][int]$TimeoutSeconds,
 [ValidateSet('eyegym')][string]$Workspace,
 [ValidateSet('read-only','workspace-write')][string]$Mode='read-only'
)
$ErrorActionPreference='Stop'
$config=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'client-config.json') -Raw | ConvertFrom-Json
if($config.version -ne 1){throw 'Unsupported helper configuration'}
$actions=@($RequestFile,$Prompt,$Status.IsPresent,$Cancel.IsPresent,$SendFile,$FetchArtifact.IsPresent,$EchoArtifact.IsPresent,$Capabilities.IsPresent)|Where-Object{$_}
if(@($actions).Count -ne 1){throw 'Choose exactly one: RequestFile, Prompt, Status, Cancel, SendFile, FetchArtifact, EchoArtifact or Capabilities'}
if($GenerateImage -and !$Prompt){throw 'GenerateImage requires Prompt'}
if($ReferenceImage -and !($Prompt -and $GenerateImage)){throw 'ReferenceImage requires Prompt and GenerateImage'}
if(($PSBoundParameters.ContainsKey('Model') -or $PSBoundParameters.ContainsKey('Effort')) -and !$Prompt){throw 'Model and Effort apply only to Prompt submissions'}
if($PSBoundParameters.ContainsKey('TimeoutSeconds') -and !$Prompt){throw 'TimeoutSeconds applies only to Prompt submissions'}
if(($PSBoundParameters.ContainsKey('Workspace') -or $PSBoundParameters.ContainsKey('Mode')) -and !$Prompt){throw 'Workspace and Mode apply only to Prompt submissions'}
if($Mode -eq 'workspace-write' -and !$Workspace){throw 'Writing requires the explicitly selected owner-authorized eyegym workspace'}
if($GenerateImage -and $Workspace){throw 'Native image generation uses a separate non-project task; submit project edits separately'}
if($PSBoundParameters.ContainsKey('Model') -and $Model -cnotmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$'){throw 'Use a model ID from the host Capabilities catalog'}
if($PSBoundParameters.ContainsKey('Effort') -and $Effort -cnotmatch '^[a-z][a-z0-9_-]{0,31}$'){throw 'Use an effort value from the host Capabilities catalog'}
if(!$TaskId -and ($Prompt -or $Capabilities)){$TaskId=[guid]::NewGuid().ToString('N')}
if(!$RequestFile -and $TaskId -notmatch '^[a-f0-9]{32}$'){throw 'TaskId must be 32 lowercase hex characters; reuse the submitted task ID for status/files'}
function Invoke-Packet($request){
 $request.version=1;$request.id=[guid]::NewGuid().ToString('N');$request.taskId=$TaskId
 $temp=Join-Path $PSScriptRoot ('request-'+[guid]::NewGuid().ToString('N')+'.json')
 try{
  [IO.File]::WriteAllText($temp,($request|ConvertTo-Json -Depth 20 -Compress),[Text.UTF8Encoding]::new($false))
  $raw=& (Join-Path $PSScriptRoot 'task-client.ps1') -RequestFile $temp -TrialHome $config.trialHome -ReasonExe $config.reasonExe
  $result=($raw -join "`n")|ConvertFrom-Json
  if($result.version -ne 1 -or $result.id -ne $request.id){throw 'Authenticated response identity mismatch'}
  if($result.state -eq 'transport_wait' -and $result.requestSent -eq $false){
   $wait=[Exception]::new('Local shared transport budget is waiting; the current packet was not sent')
   $wait.Data['TransportWaitJson']=$result|ConvertTo-Json -Depth 10 -Compress
   throw $wait
  }
  return $result
 }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Assert-Name([string]$Name){
 if($Name -notmatch '^[A-Za-z0-9][A-Za-z0-9._ -]{0,119}$' -or $Name.Contains('..') -or $Name.EndsWith('.') -or $Name.EndsWith(' ') -or $Name.Split('.')[0] -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$'){throw 'Unsafe artifact filename'}
}
function Assert-Plain([string]$Path){
 $item=Get-Item -LiteralPath $Path -Force
 while($item){if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Reparse/symlink paths are not accepted'};if($item -is [IO.FileInfo]){$item=$item.Directory}else{$item=$item.Parent}}
}
function Get-Digest([byte[]]$Bytes){
 $sha=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
}
function Save-Checkpoint($Path,$Value){
 Assert-Plain ([IO.Path]::GetDirectoryName($Path))
 if(Test-Path -LiteralPath $Path){Assert-Plain $Path}
 $temp=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{[IO.File]::WriteAllText($temp,($Value|ConvertTo-Json -Depth 20 -Compress),[Text.UTF8Encoding]::new($false));if([IO.File]::Exists($Path)){[IO.File]::Replace($temp,$Path,[System.Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($temp,$Path)}}finally{if([IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
}
function New-ReferencePreview([byte[]]$Source){
 Add-Type -AssemblyName System.Drawing
 $input=[IO.MemoryStream]::new($Source,$false);$image=$null
 try{
  $image=[Drawing.Image]::FromStream($input,$true,$true)
  if([long]$image.Width*$image.Height -gt 40000000){throw 'Reference image exceeds 40 million pixels'}
  $encoder=[Drawing.Imaging.ImageCodecInfo]::GetImageEncoders()|Where-Object{$_.MimeType -eq 'image/jpeg'}|Select-Object -First 1
  foreach($edge in @(1280,960,720,540,400,280,200,128)){
   $scale=[Math]::Min(1.0,$edge/[double][Math]::Max($image.Width,$image.Height));$w=[Math]::Max(1,[int]($image.Width*$scale));$h=[Math]::Max(1,[int]($image.Height*$scale))
   $bitmap=[Drawing.Bitmap]::new($w,$h);$graphics=[Drawing.Graphics]::FromImage($bitmap)
   try{
    $graphics.Clear([Drawing.Color]::White);$graphics.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic;$graphics.DrawImage($image,0,0,$w,$h)
    foreach($quality in @(85,65,45,30)){
     $memory=[IO.MemoryStream]::new();$options=[Drawing.Imaging.EncoderParameters]::new(1)
     try{$options.Param[0]=[Drawing.Imaging.EncoderParameter]::new([Drawing.Imaging.Encoder]::Quality,[long]$quality);$bitmap.Save($memory,$encoder,$options);$data=$memory.ToArray();if($data.Length -le 49152){return @{bytes=$data;width=$w;height=$h;originalWidth=$image.Width;originalHeight=$image.Height;quality=$quality}}}finally{$options.Dispose();$memory.Dispose()}
    }
   }finally{$graphics.Dispose();$bitmap.Dispose()}
  }
  throw 'Could not prepare a reference preview within 48 KiB'
 }finally{if($image){$image.Dispose()};$input.Dispose()}
}
$referenceTimeoutSelected=$PSBoundParameters.ContainsKey('TimeoutSeconds')
function Invoke-ReferenceUpload {
 $source=Get-Item -LiteralPath $ReferenceImage -Force;Assert-Plain $source.FullName
 if($source.PSIsContainer -or $source.Length -gt 20971520){throw 'Reference must be an ordinary image of at most 20 MiB'}
 $original=[IO.File]::ReadAllBytes($source.FullName);if($original.Length -gt 20971520){throw 'Reference grew beyond 20 MiB'}
 $originalHash=Get-Digest $original
 $selection=[ordered]@{prompt=$Prompt;model=$Model;effort=$Effort;mode=$Mode;timeoutSet=$referenceTimeoutSelected;timeout=$TimeoutSeconds}|ConvertTo-Json -Compress
 $selectionHash=Get-Digest ([Text.Encoding]::UTF8.GetBytes($selection))
 $folder=Join-Path $config.trialHome 'bridge-image-transfers';[void][IO.Directory]::CreateDirectory($folder);Assert-Plain $folder
 $path=Join-Path $folder ($TaskId+'.json')
 foreach($existing in @($path,($path+'.lock'))){if(Test-Path -LiteralPath $existing){Assert-Plain $existing}}
 $lock=[IO.File]::Open(($path+'.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 try{
  if([IO.File]::Exists($path)){
   if((Get-Item -LiteralPath $path).Length -gt 100000){throw 'Reference checkpoint too large'}
   $state=[IO.File]::ReadAllText($path)|ConvertFrom-Json
   if($state.version -ne 1 -or $state.taskId -ne $TaskId -or $state.originalSha256 -ne $originalHash -or $state.selectionHash -ne $selectionHash){throw 'Reference resume requires the unchanged source, prompt, options and taskId'}
   if($state.phase -ne 'ready'){throw 'Reference operation was sent or is uncertain; inspect this taskId instead of resubmitting'}
  }else{
   $preview=New-ReferencePreview $original;$data=$preview.bytes;$transfer=[guid]::NewGuid().ToString('N')
   $manifest=@{type='artifact-manifest';version=1;transfer_id=$transfer;name=('reference-'+$TaskId+'.jpg');mime='image/jpeg';size=$data.Length;sha256=(Get-Digest $data);chunks=[int][Math]::Ceiling($data.Length/24576.0);chunk_bytes=24576}
   $state=[pscustomobject]@{version=1;taskId=$TaskId;originalSha256=$originalHash;selectionHash=$selectionHash;phase='ready';next=0;manifest=$manifest;data=[Convert]::ToBase64String($data);preview=@{lossy=$true;mime='image/jpeg';width=$preview.width;height=$preview.height;originalWidth=$preview.originalWidth;originalHeight=$preview.originalHeight;originalSha256=$originalHash;sha256=$manifest.sha256;size=$data.Length;originalUnchanged=$true}}
   Save-Checkpoint $path $state
  }
  $data=[Convert]::FromBase64String($state.data)
  if($data.Length -gt 49152 -or (Get-Digest $data) -ne $state.manifest.sha256 -or $state.next -lt 0 -or $state.next -gt $state.manifest.chunks+1){throw 'Invalid reference checkpoint'}
  while($state.next -le $state.manifest.chunks){
   $packet=$state.manifest
   if($state.next -gt 0){$i=$state.next-1;$length=[Math]::Min(24576,$data.Length-$i*24576);$part=New-Object byte[] $length;[Array]::Copy($data,$i*24576,$part,0,$length);$packet=@{type='artifact-chunk';version=1;transfer_id=$state.manifest.transfer_id;index=$i;data=[Convert]::ToBase64String($part)};Start-Sleep -Milliseconds 1100}
   $state.phase='uncertain';Save-Checkpoint $path $state
   try{$reply=Invoke-Packet @{type='upload';artifactPacket=($packet|ConvertTo-Json -Compress)}}catch{if($_.Exception.Data.Contains('TransportWaitJson')){$state.phase='ready';Save-Checkpoint $path $state};throw}
   if($reply.state -notin @('uploading','uploaded')){throw 'Reference packet was not acknowledged; do not retry automatically'}
   if($state.next -eq $state.manifest.chunks -and ($reply.state -ne 'uploaded' -or $reply.artifact.sha256 -ne $state.manifest.sha256 -or $reply.artifact.size -ne $data.Length)){throw 'Reference upload did not verify'}
   $state.next++;$state.phase='ready';Save-Checkpoint $path $state
  }
  $state.phase='submission-uncertain';Save-Checkpoint $path $state
  return @{path=$path;state=$state}
 }finally{$lock.Dispose()}
}
try{
if($RequestFile){
 if(!(Test-Path -LiteralPath $RequestFile -PathType Leaf)){throw 'Request JSON file not found'}
 $argsToClient=@{RequestFile=[IO.Path]::GetFullPath($RequestFile);TrialHome=$config.trialHome;ReasonExe=$config.reasonExe}
 if($OutputFile){$argsToClient.OutputFile=[IO.Path]::GetFullPath($OutputFile)}
 & (Join-Path $PSScriptRoot 'task-client.ps1') @argsToClient
 return
}
if($SendFile){
 $file=Get-Item -LiteralPath $SendFile -Force
 Assert-Plain $file.FullName;Assert-Name $file.Name
 if($file.PSIsContainer -or $file.Length -gt 1048576){throw 'Send one ordinary file of at most 1 MiB'}
 $bytes=[IO.File]::ReadAllBytes($file.FullName)
 if($bytes.Length -gt 1048576){throw 'File grew beyond 1 MiB'}
 $mime='application/octet-stream'
 if($bytes.Length -ge 8 -and [BitConverter]::ToString($bytes,0,8) -eq '89-50-4E-47-0D-0A-1A-0A'){$mime='image/png'}
 elseif($bytes.Length -ge 3 -and [BitConverter]::ToString($bytes,0,3) -eq 'FF-D8-FF'){$mime='image/jpeg'}
 elseif($bytes.Length -ge 12 -and [Text.Encoding]::ASCII.GetString($bytes,0,4) -eq 'RIFF' -and [Text.Encoding]::ASCII.GetString($bytes,8,4) -eq 'WEBP'){$mime='image/webp'}
 $transfer=[guid]::NewGuid().ToString('N');$chunks=[int][Math]::Ceiling($bytes.Length/24576.0)
 $manifest=@{type='artifact-manifest';version=1;transfer_id=$transfer;name=$file.Name;mime=$mime;size=$bytes.Length;sha256=(Get-Digest $bytes);chunks=$chunks;chunk_bytes=24576}
 $result=Invoke-Packet @{type='upload';artifactPacket=($manifest|ConvertTo-Json -Compress)}
 if($result.state -notin @('uploading','uploaded')){throw 'Manifest was not accepted; inspect the private response'}
 for($i=0;$i -lt $chunks;$i++){
  Start-Sleep -Milliseconds 1100
  $length=[Math]::Min(24576,$bytes.Length-$i*24576);$part=New-Object byte[] $length;[Array]::Copy($bytes,$i*24576,$part,0,$length)
  $packet=@{type='artifact-chunk';version=1;transfer_id=$transfer;index=$i;data=[Convert]::ToBase64String($part)}
  $result=Invoke-Packet @{type='upload';artifactPacket=($packet|ConvertTo-Json -Compress)}
  if($result.state -notin @('uploading','uploaded')){throw 'Chunk was not accepted; inspect the private response'}
 }
 if($result.state -ne 'uploaded' -or $result.artifact.sha256 -ne $manifest.sha256 -or $result.artifact.size -ne $bytes.Length){throw 'Final upload receipt did not match file hash/size'}
}elseif($FetchArtifact){
 Assert-Name $ArtifactName
 if(!$DestinationDirectory){throw 'Choose a private local DestinationDirectory'}
 $destination=[IO.Path]::GetFullPath($DestinationDirectory)
 if($destination.StartsWith('\\')){throw 'Use a local destination'}
 if(!(Test-Path -LiteralPath $destination -PathType Container)){throw 'Create your destination folder first'}
 Assert-Plain $destination
 $target=Join-Path $destination $ArtifactName
 if([IO.File]::Exists($target)){throw 'Destination already exists; nothing overwritten'}
 $checkpointFolder=Join-Path $PSScriptRoot 'bridge-downloads';[void][IO.Directory]::CreateDirectory($checkpointFolder);Assert-Plain $checkpointFolder
 $checkpointKey=Get-Digest ([Text.Encoding]::UTF8.GetBytes($TaskId+'|'+$target.ToLowerInvariant()))
 $checkpointPath=Join-Path $checkpointFolder ($checkpointKey+'.json')
 foreach($existing in @($checkpointPath,($checkpointPath+'.lock'))){if(Test-Path -LiteralPath $existing){Assert-Plain $existing}}
 $downloadLock=[IO.File]::Open(($checkpointPath+'.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 try{
 $saved=$null
 if([IO.File]::Exists($checkpointPath)){
  if((Get-Item -LiteralPath $checkpointPath).Length -gt 1600000){throw 'Download checkpoint too large'}
  $saved=[IO.File]::ReadAllText($checkpointPath)|ConvertFrom-Json
  if($saved.version -ne 1 -or $saved.taskId -ne $TaskId -or $saved.target -ne $target -or $saved.phase -ne 'ready'){throw 'Download checkpoint is uncertain or mismatched; inspect before retrying'}
 }
 if(!$saved){
 $saved=[pscustomobject]@{version=1;taskId=$TaskId;target=$target;phase='uncertain';first=$null;parts=@()};Save-Checkpoint $checkpointPath $saved
 try{
 $first=Invoke-Packet @{type='artifact';name=$ArtifactName;index=0}
 }catch{if($_.Exception.Data.Contains('TransportWaitJson')){$saved.phase='ready';Save-Checkpoint $checkpointPath $saved};throw}
 $saved.first=$first;$saved.phase='ready';Save-Checkpoint $checkpointPath $saved
 }elseif($saved.first){$first=$saved.first}else{
 $saved.phase='uncertain';Save-Checkpoint $checkpointPath $saved
 try{$first=Invoke-Packet @{type='artifact';name=$ArtifactName;index=0}}catch{if($_.Exception.Data.Contains('TransportWaitJson')){$saved.phase='ready';Save-Checkpoint $checkpointPath $saved};throw}
 $saved.first=$first;$saved.phase='ready';Save-Checkpoint $checkpointPath $saved
 }
 $manifest=$first.artifactPacket|ConvertFrom-Json
 if($manifest.type -ne 'artifact-manifest' -or $manifest.version -ne 1 -or $manifest.transfer_id -notmatch '^[a-f0-9]{32}$' -or $manifest.name -ne $ArtifactName -or $manifest.size -lt 0 -or $manifest.size -gt 1048576 -or $manifest.chunk_bytes -ne 24576 -or $manifest.chunks -ne [Math]::Ceiling($manifest.size/24576.0) -or $first.count -ne $manifest.chunks+1 -or $manifest.sha256 -notmatch '^[a-f0-9]{64}$'){throw 'Invalid bounded artifact manifest'}
 $memory=[IO.MemoryStream]::new()
 try{
  if(@($saved.parts).Count -gt $manifest.chunks){throw 'Invalid saved download chunk count'}
  for($i=0;$i -lt $manifest.chunks;$i++){
   if($i -lt @($saved.parts).Count){$response=$saved.parts[$i]}else{
   Start-Sleep -Milliseconds 1100
   $saved.phase='uncertain';Save-Checkpoint $checkpointPath $saved
   try{
   $response=Invoke-Packet @{type='artifact';name=$ArtifactName;index=($i+1)}
   }catch{if($_.Exception.Data.Contains('TransportWaitJson')){$saved.phase='ready';Save-Checkpoint $checkpointPath $saved};throw}
   }
   $part=$response.artifactPacket|ConvertFrom-Json
   if($response.index -ne $i+1 -or $response.count -ne $first.count -or $part.type -ne 'artifact-chunk' -or $part.version -ne 1 -or $part.transfer_id -ne $manifest.transfer_id -or $part.index -ne $i){throw 'Artifact chunk identity mismatch'}
   $bytes=[Convert]::FromBase64String($part.data)
   if($bytes.Length -ne [Math]::Min(24576,$manifest.size-$i*24576)){throw 'Artifact chunk size mismatch'}
   if($i -ge @($saved.parts).Count){$saved.parts=@($saved.parts)+@($response);$saved.phase='ready';Save-Checkpoint $checkpointPath $saved}
   $memory.Write($bytes,0,$bytes.Length)
  }
  $bytes=$memory.ToArray()
 }finally{$memory.Dispose()}
 if($bytes.Length -ne $manifest.size -or (Get-Digest $bytes) -ne $manifest.sha256){throw 'Artifact size/hash mismatch; nothing saved'}
 $target=Join-Path $destination $ArtifactName
 $stream=[IO.File]::Open($target,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
 $result=[pscustomobject]@{version=1;state='downloaded';taskId=$TaskId;path=$target;size=$bytes.Length;sha256=$manifest.sha256}
 $saved.phase='downloaded';$saved.parts=@();Save-Checkpoint $checkpointPath $saved
 }finally{$downloadLock.Dispose()}
}elseif($EchoArtifact){
 Assert-Name $ArtifactName
 $result=Invoke-Packet @{type='echo';name=$ArtifactName}
 if($result.task.state -ne 'artifact-echo-completed' -or $result.task.codexInvocations -ne 0){throw 'Expected zero-model file echo receipt absent'}
}elseif($Prompt){
 if([Text.Encoding]::UTF8.GetByteCount($Prompt) -gt 16384){throw 'Prompt must be at most 16 KiB'}
 $request=@{type='submit';mode=$Mode.ToLowerInvariant();prompt=$Prompt}
 if($PSBoundParameters.ContainsKey('Workspace')){$request.workspace=$Workspace.ToLowerInvariant()}
 if($PSBoundParameters.ContainsKey('Model')){$request.model=$Model}
 if($PSBoundParameters.ContainsKey('Effort')){$request.effort=$Effort}
 if($PSBoundParameters.ContainsKey('TimeoutSeconds')){$request.timeoutSeconds=$TimeoutSeconds}
 if($GenerateImage){$request.operation='image'}
 if($ReferenceImage){$reference=Invoke-ReferenceUpload;$reference.state.phase='submission-uncertain';Save-Checkpoint $reference.path $reference.state}
 try{$result=Invoke-Packet $request}catch{if($ReferenceImage -and $_.Exception.Data.Contains('TransportWaitJson')){$reference.state.phase='ready';Save-Checkpoint $reference.path $reference.state};throw}
 if($ReferenceImage){$reference.state.phase='submitted';Save-Checkpoint $reference.path $reference.state;$result|Add-Member -NotePropertyName localReferencePreview -NotePropertyValue $reference.state.preview}
}elseif($Capabilities){$result=Invoke-Packet @{type='capabilities'}
 if($result.state -ne 'capabilities' -or !$result.defaults -or $null -eq $result.models){throw 'Expected host capabilities receipt absent'}
}elseif($Status){$result=Invoke-Packet @{type='status'}}
elseif($Cancel){$result=Invoke-Packet @{type='cancel'}}
$json=$result|ConvertTo-Json -Depth 20 -Compress
if($OutputFile){[IO.File]::WriteAllText([IO.Path]::GetFullPath($OutputFile),$json,[Text.UTF8Encoding]::new($false))}
Write-Output $json
}catch{
 $failure=$_.Exception
 while($failure -and !$failure.Data.Contains('TransportWaitJson')){$failure=$failure.InnerException}
 if(!$failure){throw}
 $wait=$failure.Data['TransportWaitJson']|ConvertFrom-Json
 $wait|Add-Member -NotePropertyName operationMayHavePartialTransfer -NotePropertyValue ([bool]($SendFile -or $FetchArtifact -or $ReferenceImage))
 if($ReferenceImage){$wait|Add-Member -NotePropertyName resume -NotePropertyValue 'Run the same ReferenceImage command explicitly with unchanged taskId, source, prompt and options after retryAfterSeconds; no model submission occurred for an unsent upload packet'}
 $json=$wait|ConvertTo-Json -Depth 10 -Compress
 if($OutputFile){[IO.File]::WriteAllText([IO.Path]::GetFullPath($OutputFile),$json,[Text.UTF8Encoding]::new($false))}
 Write-Output $json
}
