Reason Bridge Windows Setup 1.0.7

1. Extract this package.
2. Double-click Run-Setup.cmd.
3. Enter your one-time private pairing code only into the local wizard.
4. Wait for its actual Ready receipt, then copy the displayed instruction into Grok Bot.

Your Codex host must remain online. This public installer never receives or exports
account credentials. No administrator access, global execution-policy change,
startup service or Python installation is required on this laptop.

The launcher uses a process-scoped script policy for this setup only. Keep Grok Bot
on Ask Every Time approvals. Do not disable operating-system or browser security
warnings on the website's advice; the package is a reviewed local script bundle,
not a signed application installer.

This is a local shell helper, not a native MCP plugin. Files are checked and saved
as data, never executed. The wizard's probe makes zero model calls. Model tasks
and native images require explicit permissions on your own host.

Version 1.0.2 adds explicit -Capabilities discovery and optional -Model/-Effort on -Prompt. Use the host-returned model IDs and supported effort values. Discovery is explicit, not an extra request before every task. Omitted fields use host defaults; requested values are separate from effective values recorded in task receipts. Reinstalling reuses the existing pairing; no re-enrollment is required. The Reason file transport remains the original 1 MiB/24 KiB implementation and still has its known frequent-request/large-transfer limitation. This package does not switch to the separate Tailscale preview.

Version 1.0.3 repairs reply selection when older responses remain held: only the unique paired-host response matching the current request is approved. Older/unrelated records stay untouched. Never reset pairing or approve all messages to repair this issue. If a submission already completed on the host, recover the same taskId with -Status; do not resubmit it.

Version 1.0.4 adds optional -TimeoutSeconds on -Prompt only: 0 means unlimited, 1..604800 selects a deadline, and omission uses the host default. Existing 1.0.3 clients receive the new unlimited host default without reinstalling. Check status no faster than once every 90 seconds. A timed_out/cancelled task may list partial surviving artifacts; fetch only listed files and report the unfinished task without automatic resubmission.

Version 1.0.5 adds -Workspace eyegym and -Mode read-only|workspace-write. Read-only remains the default; writes require the explicit owner-authorized eyegym workspace. Host capabilities advertise workspaces/writeAllowed without host paths. Receipts retain actual workspaceId/mode/workspaceChanges. Changes remain in an isolated host checkout; downloading individual listed artifacts is separate. No Git commit/push, connector installation, arbitrary repository access or project source is included. Existing pairing is reused.

Version 1.0.6 serializes short same-home transport exchanges and shares a conservative 10-request/600-second budget across bots. transport_wait/requestSent:false means the current packet was not sent, not that a host job is queued. Follow retryAfterSeconds and reuse the same task ID; never automatically replay sent/uncertain submissions. Private recovery IDs are saved before send under the paired home/bridge-client-requests without prompts or credentials. Queued/running/finished jobs keep separate IDs and isolated project worktrees. Review and explicitly integrate a finished result through the private owner dashboard; conflicts/stale reviews do not merge automatically. Worker/account/resource limits remain real. Pairing, existing flags and Reason file limits are retained.

Version 1.0.7: Reference-guided image generation
Use -Prompt TEXT -GenerateImage -ReferenceImage LOCAL_FILE -TaskId HEX32. The original remains unchanged; the helper derives and labels a lossy JPEG <=48 KiB, then verifies upload before submission. Generated delivery is a labeled compressed preview; its full original remains private on the host. Fetch only the actual listed delivery artifact.
Reference and download operations checkpoint acknowledged packets locally. For transport_wait/requestSent:false, wait retryAfterSeconds and explicitly repeat the unchanged operation with the same task ID. Uncertain sends stop; do not automatically replay or regenerate. Existing pairing, model/workspace options, shared 10/600 budget and ordinary 1 MiB/24 KiB file geometry remain.
Reference previews flatten transparency onto white. Phone JPEG EXIF rotation is not normalized: check orientation before choosing the reference; quality and orientation across every source format are not established by a PNG fixture.
