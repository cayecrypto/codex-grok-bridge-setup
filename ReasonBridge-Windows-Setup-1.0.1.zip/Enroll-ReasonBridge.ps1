param([Parameter(Mandatory=$true)][string]$TrialHome,[Parameter(Mandatory=$true)][string]$ReasonExe,[switch]$PairingCodeStdin)
$Enroll=$true;$Live=$false;$Diagnose=$false
$ErrorActionPreference = 'Stop'
if($Diagnose -and ($Enroll -or $Live)) { throw 'Startup diagnostic cannot enroll or run live' }
if ((Get-FileHash -LiteralPath $ReasonExe -Algorithm SHA256).Hash.ToLowerInvariant() -ne '849a3d68bf67c3eab8a77a79f0376f343945683a8de0c8ed3297e096166838c4') { throw 'Pinned binary mismatch' }
$TrialHome = [IO.Path]::GetFullPath($TrialHome)
$encodedPair=if($PairingCodeStdin){[Console]::In.ReadToEnd().Trim()}else{Read-Host 'Paste private RB1 pairing code locally (never in chat)'}
if($encodedPair -notmatch '^RB1\.([A-Za-z0-9_-]{1,4096})$'){throw 'Expected private RB1 pairing code'}
$payload=$Matches[1].Replace('-','+').Replace('_','/');$payload+='='*((4-$payload.Length%4)%4)
$pairing=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($payload))|ConvertFrom-Json
if($pairing -isnot [pscustomobject] -or (@($pairing.PSObject.Properties.Name|Sort-Object) -join ',') -ne 'clientPerson,invite,targetPeer,version' -or $pairing.version -isnot [int] -or $pairing.invite -isnot [string] -or $pairing.clientPerson -isnot [string] -or $pairing.targetPeer -isnot [string] -or $pairing.version -ne 1 -or $pairing.clientPerson -notmatch '^device-[a-f0-9]{8}$' -or $pairing.targetPeer -ne 'codex-host/worker' -or $pairing.invite -notmatch '^[a-zA-Z0-9 -]{4,200}$'){throw 'Invalid pairing envelope'}
$ClientPerson=[string]$pairing.clientPerson
$trialConfig = @'
person="CLIENT_PERSON"
share_paths=false
share_unmanaged=false
lan=false
tray=false
reason=false
auto_update=false
[inbound]
default="hold"
'@
$trialConfig=$trialConfig.Replace('CLIENT_PERSON',$ClientPerson)
if ($Enroll) {
 if (Test-Path -LiteralPath $TrialHome) { throw 'Use a fresh dedicated trial folder' }
 foreach ($n in @('state','profile','work','temp')) { [void][IO.Directory]::CreateDirectory((Join-Path $TrialHome $n)) }
 [IO.File]::WriteAllText((Join-Path $TrialHome 'state/config.toml'),$trialConfig)
}
if (!(Test-Path -LiteralPath (Join-Path $TrialHome 'state/config.toml'))) { throw 'Enrollment required first' }
$trialActualConfig=[IO.File]::ReadAllText((Join-Path $TrialHome 'state/config.toml'))
foreach($n in @('share_paths','share_unmanaged','lan','tray','reason','auto_update')) { if(([regex]::Matches($trialActualConfig,('(?m)^'+$n+'\s*=\s*false\s*$'))).Count -ne 1) { throw ('Isolated configuration mismatch: '+$n) } }
$trialInbound=[regex]::Match($trialActualConfig,'(?ms)^\[inbound\]\s*\r?\n(.*?)(?=^\[|\z)').Groups[1].Value
if($trialActualConfig -notmatch ('(?m)^person\s*=\s*"'+[regex]::Escape($ClientPerson)+'"\s*$') -or $trialInbound -notmatch '(?m)^default\s*=\s*"hold"\s*$') { throw 'Wrong isolated person/inbound policy' }
$trialSaved=@{}
foreach ($n in @('REASON_NETWORK_HOME','USERPROFILE','HOME','TEMP','TMP')) { $trialSaved[$n]=[Environment]::GetEnvironmentVariable($n,'Process') }
$env:REASON_NETWORK_HOME=Join-Path $TrialHome 'state';$env:USERPROFILE=Join-Path $TrialHome 'profile';$env:HOME=$env:USERPROFILE;$env:TEMP=Join-Path $TrialHome 'temp';$env:TMP=$env:TEMP
$trialChildren=New-Object 'System.Collections.Generic.List[System.Diagnostics.Process]'
$trialJoinId=$null;$trialJoinStartedUtc=$null
function Read-TrialLockPid([string]$Path) {
 $stream=$null;$reader=$null
 try {
  $stream=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
  $reader=New-Object IO.StreamReader($stream);$value=$reader.ReadToEnd().Trim()
  if($value -notmatch '^\d{1,10}$'){throw 'Unexpected trial lock contents'}
  return [int]$value
 } finally {if($reader){$reader.Dispose()}elseif($stream){$stream.Dispose()}}
}
function Test-TrialReplacementIdentity($Meta,[string]$ExpectedExe,[int]$JoinId,[datetime]$JoinStartedUtc,[datetime]$HandleStartedUtc) {
 if(!$Meta -or $Meta.Name -ne 'reason-network.exe' -or $Meta.ParentProcessId -ne $JoinId -or ![string]::Equals($Meta.ExecutablePath,[IO.Path]::GetFullPath($ExpectedExe),[StringComparison]::OrdinalIgnoreCase)){return $false}
 $created=$Meta.CreationDate.ToUniversalTime()
 return ($created -ge $JoinStartedUtc.AddMilliseconds(-2) -and $created -le [DateTime]::UtcNow.AddMilliseconds(2) -and [Math]::Abs(($created-$HandleStartedUtc).TotalMilliseconds) -le 2)
}
function Stop-TrialEnrollmentReplacement {
 $lockPath=Join-Path $TrialHome 'state/daemon.lock';$replacementId=Read-TrialLockPid $lockPath
 $replacement=Get-Process -Id $replacementId -ErrorAction SilentlyContinue
 if(!$replacement) {
  $remaining=@(Get-CimInstance Win32_Process -Filter ("ParentProcessId="+$trialJoinId+" AND Name='reason-network.exe'"))
  if($remaining.Count){throw 'Join child exists without verified state ownership'}
  return
 }
 [void]$replacement.Handle
 $meta=Get-CimInstance Win32_Process -Filter ('ProcessId='+$replacementId)
 if(!(Test-TrialReplacementIdentity -Meta $meta -ExpectedExe $ReasonExe -JoinId $trialJoinId -JoinStartedUtc $trialJoinStartedUtc -HandleStartedUtc ($replacement.StartTime.ToUniversalTime()))){throw 'Replacement ownership mismatch'}
 if((Get-FileHash -LiteralPath $ReasonExe -Algorithm SHA256).Hash.ToLowerInvariant() -ne '849a3d68bf67c3eab8a77a79f0376f343945683a8de0c8ed3297e096166838c4'){throw 'Replacement binary changed'}
 if((Read-TrialLockPid $lockPath) -ne $replacementId -or $replacement.HasExited){throw 'Replacement ownership changed'}
 $trialChildren.Add($replacement);$replacement.Kill()
 if(!$replacement.WaitForExit(5000)){throw 'Replacement exit unconfirmed'}
 Write-Output ('Identified enrollment replacement daemon exited: '+$replacementId)
}
function Start-TrialReason([string]$Arguments) {
 if($Arguments -ne 'daemon' -and $daemon.HasExited) { throw 'Owned daemon ended; refuse detached auto-start' }
 $i=New-Object Diagnostics.ProcessStartInfo
 $i.FileName=$ReasonExe;$i.Arguments=$Arguments;$i.WorkingDirectory=Join-Path $TrialHome 'work';$i.UseShellExecute=$false;$i.CreateNoWindow=$true
 $i.RedirectStandardInput=$true;$i.RedirectStandardOutput=$true;$i.RedirectStandardError=$true
 $i.StandardOutputEncoding=[Text.Encoding]::UTF8;$i.StandardErrorEncoding=[Text.Encoding]::UTF8
 $p=New-Object Diagnostics.Process;$p.StartInfo=$i;[void]$p.Start();$p.StandardInput.Close();$trialChildren.Add($p);return $p
}
try {
 if($Enroll) {
  $privateInvite=[string]$pairing.invite;$encodedPair=$null;$payload=$null;$pairing=$null
  if ($privateInvite -notmatch '^[a-zA-Z0-9 -]{4,200}$') { throw 'Expected one-time word code' }
 }
 $daemon=Start-TrialReason 'daemon';$daemonOut=$daemon.StandardOutput.ReadToEndAsync();$daemonErr=$daemon.StandardError.ReadToEndAsync();Start-Sleep -Milliseconds 1000
 if($Diagnose) {
  $trialStartupSucceeded=!$daemon.HasExited
  if(!$daemon.HasExited) { $daemon.Kill();if(!$daemon.WaitForExit(5000)){throw 'Diagnostic child cleanup unconfirmed'} }
  $trialRawDiagnostic=$daemonOut.Result+"`n"+$daemonErr.Result
  [IO.File]::WriteAllText((Join-Path $TrialHome 'daemon-startup.private.log'),$trialRawDiagnostic)
  $trialReason='unclassified; inspect local private daemon-startup.private.log'
  foreach($candidate in @('another daemon is already running','Access is denied','Permission denied','invalid TOML','failed to parse','database is locked','address already in use')) { if($trialRawDiagnostic.IndexOf($candidate,[StringComparison]::OrdinalIgnoreCase) -ge 0){$trialReason=$candidate;break} }
  [pscustomobject]@{Diagnostic='startup-only';AliveAfterOneSecond=$trialStartupSucceeded;ExitCode=$daemon.ExitCode;Reason=$trialReason;RawLog='daemon-startup.private.log (local private file)';ModelInvocations=0}|ConvertTo-Json -Compress
  return
 }
 if ($daemon.HasExited) { throw 'Owned daemon failed; do not auto-start another' }
 if ($Enroll) {
  $join=Start-TrialReason ('join "'+$privateInvite+'" --as '+$ClientPerson+' --no-setup');$privateInvite=$null
  $trialJoinId=$join.Id;$trialJoinStartedUtc=$join.StartTime.ToUniversalTime()
  $joinOut=$join.StandardOutput.ReadToEndAsync();$joinErr=$join.StandardError.ReadToEndAsync()
  if (!$join.WaitForExit(30000)) { throw 'Join timeout' };if ($join.ExitCode -ne 0) { throw 'Join failed; inspect local private diagnostics' }
  [IO.File]::WriteAllText((Join-Path $TrialHome 'bridge-client.json'),(@{version=1;clientPerson=$ClientPerson;targetPeer='codex-host/worker'}|ConvertTo-Json -Compress));Write-Output 'ENROLLED own device; no provider login or model call.'
 }
} finally {
 foreach ($p in $trialChildren) { if (!$p.HasExited) { $p.Kill() };[void]$p.WaitForExit(5000) }
 $trialReplacementIssue=$null
 if($Enroll -and $trialJoinId) {try{Stop-TrialEnrollmentReplacement}catch{$trialReplacementIssue='Enrollment replacement ownership/cleanup unconfirmed; no unverified process stopped'}}
 foreach ($n in $trialSaved.Keys) { [Environment]::SetEnvironmentVariable($n,$trialSaved[$n],'Process') }
 if($trialReplacementIssue){throw $trialReplacementIssue}
 if(@($trialChildren|Where-Object {!$_.HasExited}).Count -ne 0) { throw 'Tracked child cleanup unconfirmed' }
 Write-Output 'Tracked trial child cleanup confirmed.'
}
