@echo off
setlocal
title Reason Bridge Setup
rem This policy applies only to this reviewed setup process, never the machine.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-ReasonBridge.ps1"
if errorlevel 1 (
 echo.
 echo Setup stopped. Read the message above; no model request was submitted.
 pause
 exit /b 1
)
pause
