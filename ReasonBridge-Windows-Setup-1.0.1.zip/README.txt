Reason Bridge Windows Setup

1. Extract this package.
2. Double-click Run-Setup.cmd.
3. Enter your one-time private pairing code only into the local wizard.
4. Wait for its actual Ready receipt, then copy the displayed instruction into Grok Bot.

Your Codex host must remain online. This public installer never receives or exports
account credentials. No administrator access, global execution-policy change,
startup service or Python installation is required on this laptop.

The launcher uses a process-scoped script policy for this setup only. Keep Grok Bot
on Ask Every Time approvals. Do not disable operating-system or browser security
warnings on the website's advice; the package is a reviewed local script bundle,
not a signed application installer.

This is a local shell helper, not a native MCP plugin. Files are checked and saved
as data, never executed. The wizard's probe makes zero model calls. Model tasks
and native images require explicit permissions on your own host.
