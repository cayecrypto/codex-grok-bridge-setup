param([Parameter(Mandatory=$true)][string]$RequestFile,[Parameter(Mandatory=$true)][string]$TrialHome,[Parameter(Mandatory=$true)][string]$ReasonExe,[string]$OutputFile)
$ErrorActionPreference='Stop'
$req=Get-Content -LiteralPath $RequestFile -Raw|ConvertFrom-Json
if($req.version -ne 1 -or $req.id -notmatch '^[a-f0-9]{32}$' -or $req.taskId -notmatch '^[a-f0-9]{32}$' -or $req.type -notin @('submit','status','cancel','artifact','upload','echo','capabilities')){throw 'Invalid request envelope'}
if((Get-FileHash -LiteralPath $ReasonExe).Hash.ToLowerInvariant() -ne '849a3d68bf67c3eab8a77a79f0376f343945683a8de0c8ed3297e096166838c4'){throw 'Pinned binary mismatch'}
$ClientPerson='remote-laptop';$TargetPeer='codex-host/worker'
$identityPath=Join-Path $TrialHome 'bridge-client.json'
if(Test-Path -LiteralPath $identityPath){$identity=Get-Content -LiteralPath $identityPath -Raw|ConvertFrom-Json;if($identity -isnot [pscustomobject] -or (@($identity.PSObject.Properties.Name|Sort-Object) -join ',') -ne 'clientPerson,targetPeer,version' -or $identity.version -isnot [int] -or $identity.clientPerson -isnot [string] -or $identity.targetPeer -isnot [string] -or $identity.version -ne 1 -or $identity.clientPerson -notmatch '^(device-[a-f0-9]{8}|remote-laptop)$' -or $identity.targetPeer -ne 'codex-host/worker'){throw 'Invalid client identity'};$ClientPerson=[string]$identity.clientPerson;$TargetPeer=[string]$identity.targetPeer}
$cfg=[IO.File]::ReadAllText((Join-Path $TrialHome 'state/config.toml'))
foreach($key in @('share_paths','share_unmanaged','lan','tray','reason','auto_update')){if(([regex]::Matches($cfg,('(?m)^'+$key+'\s*=\s*false\s*$'))).Count -ne 1){throw 'Isolated configuration required'}}
if($cfg -notmatch ('(?m)^person\s*=\s*"'+[regex]::Escape($ClientPerson)+'"\s*$') -or $cfg -notmatch '(?ms)^\[inbound\]\s*\r?\n.*?^default\s*=\s*"hold"\s*$'){throw 'Wrong paired identity/policy'}
$saved=@{};$children=New-Object 'System.Collections.Generic.List[System.Diagnostics.Process]'
function Start-Reason([string]$ArgsText,[string]$InputText=''){
 if($ArgsText -ne 'daemon' -and $daemon.HasExited){throw 'Owned daemon ended; no autostart'}
 $i=New-Object Diagnostics.ProcessStartInfo;$i.FileName=$ReasonExe;$i.Arguments=$ArgsText;$i.WorkingDirectory=Join-Path $TrialHome 'work';$i.UseShellExecute=$false;$i.CreateNoWindow=$true
 $i.RedirectStandardInput=$true;$i.RedirectStandardOutput=$true;$i.RedirectStandardError=$true;$i.StandardOutputEncoding=[Text.Encoding]::UTF8;$i.StandardErrorEncoding=[Text.Encoding]::UTF8
 $p=New-Object Diagnostics.Process;$p.StartInfo=$i;[void]$p.Start();$children.Add($p)
 if($InputText){$p.StandardInput.Write($InputText)};$p.StandardInput.Close()
 return $p
}
function Run-Reason([string]$ArgsText,[string]$InputText=''){
 $p=Start-Reason $ArgsText $InputText;$out=$p.StandardOutput.ReadToEndAsync();$err=$p.StandardError.ReadToEndAsync()
 if(!$p.WaitForExit(8000)){throw 'Reason command timed out'};if($p.ExitCode -ne 0){throw 'Reason command failed'};return $out.Result
}
function Read-ResponsePacket([string]$Body){
 if($Body -notmatch '^RNB1:[A-Za-z0-9+/=]+$' -or $Body.Length -gt 64000){throw 'Invalid response packet'}
 $v=([Text.UTF8Encoding]::new($false,$true)).GetString([Convert]::FromBase64String($Body.Substring(5)))|ConvertFrom-Json
 if($v -isnot [pscustomobject] -or ($v.version -isnot [int] -and $v.version -isnot [long]) -or $v.version -ne 1 -or $v.id -isnot [string] -or $v.id -cnotmatch '^[a-f0-9]{32}$'){throw 'Invalid response schema'}
 return $v
}
function Decode-Packet([string]$Body){
 $v=Read-ResponsePacket $Body
 if($v.id -cne $req.id -or ($v.PSObject.Properties.Name -contains 'taskId' -and $v.taskId -cne $req.taskId) -or ($v.task -and $v.task.PSObject.Properties.Name -contains 'taskId' -and $v.task.taskId -cne $req.taskId)){throw 'Response request identity mismatch'}
 return $v
}
function Enter-TransportLock([string]$ClientHome,[int]$WaitMilliseconds=120000){
 $canonical=[IO.Path]::GetFullPath($ClientHome)
 $path=Join-Path $canonical 'bridge-transport.lock'
 $watch=[Diagnostics.Stopwatch]::StartNew()
 while($true){
  if(Test-Path -LiteralPath $path){if((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Transport lock reparse point refused; no request sent'}}
  try{return [IO.File]::Open($path,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
  catch [IO.IOException]{
   if(($_.Exception.HResult -band 65535) -notin @(32,33)){throw}
   if($watch.ElapsedMilliseconds -ge $WaitMilliseconds){throw 'Client transport busy; no request sent. Wait for the other local exchange to exit.'}
   Start-Sleep -Milliseconds 200
  }
 }
}
function Read-TransportBudget([string]$ClientHome,[long]$NowMilliseconds){
 if(!$PSBoundParameters.ContainsKey('NowMilliseconds')){$NowMilliseconds=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()}
 $path=Join-Path ([IO.Path]::GetFullPath($ClientHome)) 'bridge-transport-budget.json';$history=@()
 if(Test-Path -LiteralPath $path){
  $file=Get-Item -LiteralPath $path -Force
  if(($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $file.Length -gt 16384){throw 'Invalid local message budget; no request sent'}
  $value=[IO.File]::ReadAllText($path)|ConvertFrom-Json
  if($value -isnot [pscustomobject] -or (@($value.PSObject.Properties.Name|Sort-Object) -join ',') -ne 'sentAt,version' -or ($value.version -isnot [int] -and $value.version -isnot [long]) -or $value.version -ne 1 -or $value.sentAt -isnot [Array] -or $value.sentAt.Count -gt 10){throw 'Invalid local message budget; no request sent'}
  foreach($stamp in $value.sentAt){
   if(($stamp -isnot [long] -and $stamp -isnot [int]) -or $stamp -lt 0 -or $stamp -gt $NowMilliseconds+86400000){throw 'Invalid local message budget timestamp; no request sent'}
   if($stamp -gt $NowMilliseconds-600000){$history+=[long]$stamp}
  }
 }
 $retry=0
 if($history.Count -ge 10){$earliest=($history|Measure-Object -Minimum).Minimum;$retry=[int][Math]::Max(1,[Math]::Ceiling(($earliest+600000-$NowMilliseconds)/1000.0))}
 return [pscustomobject]@{allowed=($history.Count -lt 10);retryAfterSeconds=$retry;sentAt=@($history)}
}
function Reserve-TransportBudget([string]$ClientHome,[long]$NowMilliseconds){
 if(!$PSBoundParameters.ContainsKey('NowMilliseconds')){$NowMilliseconds=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()}
 $budget=Read-TransportBudget $ClientHome $NowMilliseconds
 if(!$budget.allowed){return $budget}
 $path=Join-Path ([IO.Path]::GetFullPath($ClientHome)) 'bridge-transport-budget.json';$temp=$path+'.new-'+[guid]::NewGuid().ToString('N')
 $json=@{version=1;sentAt=@($budget.sentAt)+@($NowMilliseconds)}|ConvertTo-Json -Compress
 try{
  $stream=[IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
  try{$bytes=[Text.Encoding]::UTF8.GetBytes($json);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
  if([IO.File]::Exists($path)){[IO.File]::Replace($temp,$path,[NullString]::Value)}else{[IO.File]::Move($temp,$path)}
 }finally{if([IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
 return $budget
}
function Write-TransportWait($Budget){
 $local=@{version=1;id=$req.id;taskId=$req.taskId;state='transport_wait';requestSent=$false;retryAfterSeconds=$Budget.retryAfterSeconds;transport='local-shared-message-budget'}
 $json=$local|ConvertTo-Json -Compress
 if($OutputFile){[IO.File]::WriteAllText($OutputFile,$json,[Text.UTF8Encoding]::new($false))}
 Write-Output $json
}
function Save-SubmissionIdentity([string]$ClientHome,$Request){
 if($Request.type -ne 'submit'){return}
 $folder=Join-Path ([IO.Path]::GetFullPath($ClientHome)) 'bridge-client-requests'
 [void][IO.Directory]::CreateDirectory($folder)
 if((Get-Item -LiteralPath $folder -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Submission identity folder reparse point refused; no request sent'}
 $path=Join-Path $folder ($Request.taskId+'.json')
 if(Test-Path -LiteralPath $path){
  $file=Get-Item -LiteralPath $path -Force
  if(($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $file.Length -gt 16384){throw 'Invalid saved submission identity; no request sent'}
  $record=[IO.File]::ReadAllText($path)|ConvertFrom-Json
  if($record.taskId -cne $Request.taskId){throw 'Saved submission task identity mismatch; no request sent'}
 }else{$record=[pscustomobject]@{version=1;taskId=$Request.taskId;createdAt=[DateTime]::UtcNow.ToString('o')}}
 $record|Add-Member -Force -NotePropertyName lastRequestId -NotePropertyValue $Request.id
 $record|Add-Member -Force -NotePropertyName requestSent -NotePropertyValue 'unknown'
 $record|Add-Member -Force -NotePropertyName preparedAt -NotePropertyValue ([DateTime]::UtcNow.ToString('o'))
 $temp=$path+'.new-'+[guid]::NewGuid().ToString('N')
 try{
  $stream=[IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
  try{$bytes=[Text.Encoding]::UTF8.GetBytes(($record|ConvertTo-Json -Compress));$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
  if([IO.File]::Exists($path)){[IO.File]::Replace($temp,$path,[NullString]::Value)}else{[IO.File]::Move($temp,$path)}
 }finally{if([IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
}
function Select-HeldResponse([string]$Held,[string]$ExpectedId,[string]$ExpectedTaskId){
 if([Text.Encoding]::UTF8.GetByteCount($Held) -gt 1MB){throw 'Held output exceeds bounded parser limit; no approval'}
 $text=$Held.Replace("`r`n","`n")
 if($text -ceq "Nothing held.`n" -or $text -ceq 'Nothing held.'){return $null}
 $footer='`reason-network approve <id>` delivers, `reason-network reject <id>` drops (or --all).'+"`n"
 if(!$text.EndsWith($footer,[StringComparison]::Ordinal)){throw 'Unexpected held footer; no approval'}
 $records=$text.Substring(0,$text.Length-$footer.Length)
 $pattern='\u2500\u2500 ([a-z0-9_-]+/[a-z0-9_-]+)(?: \([^\n]*\))? \u00b7 [^\n]+ ago \u00b7 ([A-Z0-9]{26})\n(RNB1:[A-Za-z0-9+/=]+)\n\n'
 $matches=[regex]::Matches($records,$pattern)
 if($matches.Count -lt 1 -or $matches.Count -gt 128 -or (($matches|ForEach-Object{$_.Value}) -join '') -cne $records){throw 'Unexpected held record; no approval'}
 $seen=@{};$selected=@()
 foreach($record in $matches){
  $messageId=$record.Groups[2].Value
  if($seen.ContainsKey($messageId)){throw 'Duplicate held message ID; no approval'};$seen[$messageId]=$true
  if($record.Groups[1].Value -cne 'codex-host/worker'){continue}
  try{$packet=Read-ResponsePacket $record.Groups[3].Value}catch{continue}
  if($packet.id -cne $ExpectedId){continue}
  if(($packet.PSObject.Properties.Name -contains 'taskId' -and $packet.taskId -cne $ExpectedTaskId) -or ($packet.task -and $packet.task.PSObject.Properties.Name -contains 'taskId' -and $packet.task.taskId -cne $ExpectedTaskId)){throw 'Held response task identity mismatch; no approval'}
  $selected+= [pscustomobject]@{messageId=$messageId;body=$record.Groups[3].Value}
 }
 if($selected.Count -gt 1){throw 'Ambiguous matching held responses; no approval'}
 if($selected.Count -eq 1){return $selected[0]}
 return $null
}
$transportLock=$null
try{
 $transportLock=Enter-TransportLock $TrialHome
 foreach($key in @('REASON_NETWORK_HOME','USERPROFILE','HOME','TEMP','TMP')){$saved[$key]=[Environment]::GetEnvironmentVariable($key,'Process')}
 $budget=Read-TransportBudget $TrialHome
 if(!$budget.allowed){Write-TransportWait $budget;return}
 $env:REASON_NETWORK_HOME=Join-Path $TrialHome 'state';$env:USERPROFILE=Join-Path $TrialHome 'profile';$env:HOME=$env:USERPROFILE;$env:TEMP=Join-Path $TrialHome 'temp';$env:TMP=$env:TEMP
 $daemon=Start-Reason 'daemon';$do=$daemon.StandardOutput.ReadToEndAsync();$de=$daemon.StandardError.ReadToEndAsync();Start-Sleep -Milliseconds 800
 if($daemon.HasExited){throw 'Owned daemon failed; do not reuse another daemon'}
 $listen=Start-Reason 'listen --as client --wait 30';$lo=$listen.StandardOutput.ReadToEndAsync();$le=$listen.StandardError.ReadToEndAsync();Start-Sleep -Milliseconds 400
 $body='RNB1:'+[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($req|ConvertTo-Json -Depth 10 -Compress)))
 if($body.Length -gt 64000){throw 'Request too large'}
 # Reserve at the actual send boundary; an uncertain send still consumes this slot.
 $budget=Reserve-TransportBudget $TrialHome
 if(!$budget.allowed){Write-TransportWait $budget;return}
 Save-SubmissionIdentity $TrialHome $req
 $null=Run-Reason 'send codex-host/worker - --from client' $body
 $deadline=[DateTime]::UtcNow.AddSeconds(30)
 while(!$listen.HasExited -and [DateTime]::UtcNow -lt $deadline){
  $held=Run-Reason 'held'
   $selected=Select-HeldResponse $held $req.id $req.taskId
   if($selected){$null=Decode-Packet $selected.body;$null=Run-Reason ('approve '+$selected.messageId);break}
   Start-Sleep -Milliseconds 1000
 }
 if(!$listen.WaitForExit(5000)){throw 'Response timed out'}
 $footer="From codex-host's agent. Reply if useful: reason-network send codex-host/worker --from "+$ClientPerson+'/client "<reply>"'
 $pattern='\A<reason-message from="codex-host/worker"[^>]*>\r?\n(RNB1:[A-Za-z0-9+/=]+)\r?\n</reason-message>\r?\n(?:'+[regex]::Escape($footer)+'\r?\n)?\s*\z'
 $m=[regex]::Match($lo.Result,$pattern)
 if(!$m.Success){throw 'Expected paired response absent'};$result=Decode-Packet $m.Groups[1].Value;$json=$result|ConvertTo-Json -Depth 20 -Compress
 if($OutputFile){[IO.File]::WriteAllText($OutputFile,$json)};Write-Output $json
}finally{
 $cleanupFailed=$false
 foreach($p in $children){try{if(!$p.HasExited){$p.Kill()};if(!$p.WaitForExit(5000)){$cleanupFailed=$true}}catch{$cleanupFailed=$true}}
 foreach($key in $saved.Keys){[Environment]::SetEnvironmentVariable($key,$saved[$key],'Process')}
 if($cleanupFailed){throw 'Owned child exit unconfirmed; transport lock is not explicitly released'}
 if($transportLock){$transportLock.Dispose()}
}
