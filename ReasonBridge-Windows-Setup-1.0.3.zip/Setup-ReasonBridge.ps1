param([string]$InstallHome=(Join-Path $env:LOCALAPPDATA 'ReasonBridge'))
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$pinExe='849a3d68bf67c3eab8a77a79f0376f343945683a8de0c8ed3297e096166838c4'
$pinZip='82409b9d9ee97f59738cc4cfd19f8561cc7995593ffc260fbdb42142e94c39e2'
$release='https://github.com/reason-machines/reason-network/releases/download/v0.10.8/reason-network-x86_64-pc-windows-msvc.zip'
$InstallHome=[IO.Path]::GetFullPath($InstallHome)
if($InstallHome.StartsWith('\\')){throw 'Choose a private local installation folder'}
function Write-Json([string]$Path,$Value){[IO.File]::WriteAllText($Path,($Value|ConvertTo-Json -Depth 15),[Text.UTF8Encoding]::new($false))}
function Check-Home([string]$ClientHome){
 $path=Join-Path $ClientHome 'state/config.toml'
 if(!(Test-Path -LiteralPath $path -PathType Leaf)){return $false}
 $cfg=[IO.File]::ReadAllText($path)
 if($cfg -notmatch '(?m)^person\s*=\s*"(remote-laptop|device-[a-f0-9]{8})"\s*$'){throw 'The selected state belongs to another identity; it will not be changed'}
 $person=$Matches[1]
 if($person -ne 'remote-laptop'){
  $identityPath=Join-Path $ClientHome 'bridge-client.json'
  if(!(Test-Path -LiteralPath $identityPath -PathType Leaf)){throw 'Existing device identity is incomplete; it will not be overwritten'}
  $identity=Get-Content -LiteralPath $identityPath -Raw|ConvertFrom-Json
  if($identity.version -ne 1 -or $identity.clientPerson -ne $person -or $identity.targetPeer -ne 'codex-host/worker'){throw 'Existing device identity does not match isolated state'}
 }
 foreach($key in @('share_paths','share_unmanaged','lan','tray','reason','auto_update')){if(([regex]::Matches($cfg,('(?m)^'+$key+'\s*=\s*false\s*$'))).Count -ne 1){throw 'Existing state does not match isolated client settings'}}
 if($cfg -notmatch '(?ms)^\[inbound\]\s*\r?\n.*?^default\s*=\s*"hold"\s*$'){throw 'Existing inbound policy must hold by default'}
 return $true
}
Write-Host ''
Write-Host 'REASON BRIDGE | Connect this Windows laptop' -ForegroundColor Cyan
Write-Host 'This installs your local helper, privately pairs with your host and verifies a zero-model request.'
Write-Host 'No account login, administrator permission, global policy change or model request is needed.'
Write-Host ''
Write-Host '[1/4] Verify the setup package'
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'package-sha256.json') -Raw|ConvertFrom-Json
foreach($name in @('Enroll-ReasonBridge.ps1','task-client.ps1','Invoke-ReasonBridge.ps1')){
 $source=Join-Path $PSScriptRoot $name
 if(!(Test-Path -LiteralPath $source) -or (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.$name){throw 'Setup package checksum mismatch. Download a fresh reviewed package.'}
}
$configPath=Join-Path $InstallHome 'client-config.json'
$config=$null
if(Test-Path -LiteralPath $configPath){$config=Get-Content -LiteralPath $configPath -Raw|ConvertFrom-Json;if($config.version -ne 1){throw 'Unsupported existing helper configuration'}}
[void][IO.Directory]::CreateDirectory($InstallHome)
Write-Json (Join-Path $InstallHome 'setup-receipt.json') @{version=1;state='installing';transportVerified=$false;checkedAt=[DateTime]::UtcNow.ToString('o');modelCalls=0}
Write-Host '[2/4] Prepare the verified Reason binary'
$reason=$null
if($config -and (Test-Path -LiteralPath $config.reasonExe -PathType Leaf)){
 if((Get-FileHash -LiteralPath $config.reasonExe -Algorithm SHA256).Hash.ToLowerInvariant() -eq $pinExe){$reason=$config.reasonExe}
}
$binaryRoot=Join-Path $InstallHome 'reason-0.10.8'
if(!$reason -and (Test-Path -LiteralPath $binaryRoot)){
 $found=@(Get-ChildItem -LiteralPath $binaryRoot -File -Filter reason-network.exe -Recurse)
 if($found.Count -eq 1 -and (Get-FileHash -LiteralPath $found[0].FullName -Algorithm SHA256).Hash.ToLowerInvariant() -eq $pinExe){$reason=$found[0].FullName}
}
if(!$reason){
 Write-Host 'Downloading the official pinned Windows binary (no paid service).'
 $archive=Join-Path $InstallHome 'reason-network-0.10.8.zip'
 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 Invoke-WebRequest -UseBasicParsing -Uri $release -OutFile $archive
 if((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $pinZip){throw 'Official download checksum mismatch; nothing will run'}
 $extract=Join-Path $InstallHome ('binary-'+[guid]::NewGuid().ToString('N'))
 Expand-Archive -LiteralPath $archive -DestinationPath $extract
 $found=@(Get-ChildItem -LiteralPath $extract -File -Filter reason-network.exe -Recurse)
 if($found.Count -ne 1 -or (Get-FileHash -LiteralPath $found[0].FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $pinExe){throw 'Pinned executable mismatch; nothing will run'}
 $reason=$found[0].FullName
}
Write-Host '[3/4] Reuse pairing or pair privately'
$trial=$null
if($config){if(Check-Home $config.trialHome){$trial=$config.trialHome}}
$legacy=Join-Path $env:LOCALAPPDATA 'ReasonNetworkTrial-20261021/home'
if(!$trial -and (Test-Path -LiteralPath $legacy)){
 if(Check-Home $legacy){$trial=$legacy;Write-Host 'Found your existing isolated pairing. It will be reused.'}
}
foreach($name in @('Enroll-ReasonBridge.ps1','task-client.ps1','Invoke-ReasonBridge.ps1')){
 $target=Join-Path $InstallHome $name
 if(Test-Path -LiteralPath $target){
  if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -eq $manifest.$name){continue}
  $backup=$target+'.previous-'+[guid]::NewGuid().ToString('N')
  Copy-Item -LiteralPath $target -Destination $backup
 }
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $target -Force
}
if(!$trial){
 $trial=Join-Path $InstallHome ('home-'+[guid]::NewGuid().ToString('N').Substring(0,8))
 Write-Host 'Keep your host online. Enter its one-time private invitation only at the next local prompt.'
 Write-Host 'Do not paste the invitation into Grok Bot, chat, the website or a URL.'
 & (Join-Path $InstallHome 'Enroll-ReasonBridge.ps1') -TrialHome $trial -ReasonExe $reason
 if(!(Check-Home $trial)){throw 'Pairing state is unconfirmed'}
}
$newConfig=@{version=1;reasonExe=$reason;trialHome=$trial}
Write-Json $configPath $newConfig
Write-Host '[4/4] Verify your host with a zero-model status request'
$probeTask=[guid]::NewGuid().ToString('N')
$probe=& (Join-Path $InstallHome 'Invoke-ReasonBridge.ps1') -Status -TaskId $probeTask
$result=($probe -join "`n")|ConvertFrom-Json
if($result.task.taskId -ne $probeTask -or $result.task.state -ne 'not-found'){throw 'Expected authenticated status receipt absent. Host may be offline; setup is installed but connection is not verified.'}
$receipt=@{version=1;state='ready';transportVerified=$true;checkedAt=[DateTime]::UtcNow.ToString('o');probeTaskId=$probeTask;modelCalls=0}
Write-Json (Join-Path $InstallHome 'setup-receipt.json') $receipt
$instructions=@'
Use my installed local Windows helper at $env:LOCALAPPDATA\ReasonBridge\Invoke-ReasonBridge.ps1 through your local shell tool, not a cloud shell. Keep Ask Every Time approvals enabled. Call -Capabilities explicitly once to discover the actual host model IDs, supportedEfforts, defaults, inputModalities and nativeImageGenerationVerified; cache that catalog rather than adding discovery to every request. Choose a model/effort suitable for my task from that catalog and pass -Model and -Effort with -Prompt. Omit either option to use host defaults. Never guess unsupported values or switch providers. Distinguish requested selection from the effective model/effort recorded in the task receipt; if the receipt does not confirm it, say unconfirmed. The nativeImageGenerationVerified flag records the separate host image proof; it does not establish every model as an image generator or prove remote file delivery. Send my task with -Prompt, retain the returned taskId and check -Status until the actual receipt is terminal, avoiding frequent polling because Reason limits requests. A failed reply does not prove the task failed: recover its existing taskId with -Status rather than submitting it again. Report errors; never resubmit automatically or add a paid/API fallback. Upload requested inputs with -SendFile before submitting the same taskId. Fetch only listed completed artifacts with -FetchArtifact, -ArtifactName and an existing local -DestinationDirectory; report the verified saved path/hash. Never execute downloaded attachments. Native image requests use -Prompt plus -GenerateImage only after I enable image generation on my host. This is a local shell bridge, not a native MCP plugin; automatic file cards are not established.
'@
[IO.File]::WriteAllText((Join-Path $InstallHome 'Grok-Bot-Instructions.txt'),$instructions,[Text.UTF8Encoding]::new($false))
Write-Host ''
Write-Host 'READY: your paired host returned an authenticated matching response. Model calls: 0.' -ForegroundColor Green
Write-Host ('Helper: '+(Join-Path $InstallHome 'Invoke-ReasonBridge.ps1'))
Write-Host 'Paste this one-time instruction into Grok Bot:'
Write-Host $instructions
Write-Host ('Saved instruction: '+(Join-Path $InstallHome 'Grok-Bot-Instructions.txt'))
