Reason Bridge Windows Setup

1. Extract this package.
2. Double-click Run-Setup.cmd.
3. Enter your one-time private pairing code only into the local wizard.
4. Wait for its actual Ready receipt, then copy the displayed instruction into Grok Bot.

Your Codex host must remain online. This public installer never receives or exports
account credentials. No administrator access, global execution-policy change,
startup service or Python installation is required on this laptop.

The launcher uses a process-scoped script policy for this setup only. Keep Grok Bot
on Ask Every Time approvals. Do not disable operating-system or browser security
warnings on the website's advice; the package is a reviewed local script bundle,
not a signed application installer.

This is a local shell helper, not a native MCP plugin. Files are checked and saved
as data, never executed. The wizard's probe makes zero model calls. Model tasks
and native images require explicit permissions on your own host.

Version 1.0.2 adds explicit -Capabilities discovery and optional -Model/-Effort on -Prompt. Use the host-returned model IDs and supported effort values. Discovery is explicit, not an extra request before every task. Omitted fields use host defaults; requested values are separate from effective values recorded in task receipts. Reinstalling reuses the existing pairing; no re-enrollment is required. The Reason file transport remains the original 1 MiB/24 KiB implementation and still has its known frequent-request/large-transfer limitation. This package does not switch to the separate Tailscale preview.
