param(
 [string]$RequestFile,[string]$Prompt,[switch]$GenerateImage,[switch]$Status,[switch]$Cancel,
 [string]$TaskId,[string]$SendFile,[switch]$FetchArtifact,[switch]$EchoArtifact,
 [string]$ArtifactName='response.txt',[string]$DestinationDirectory,
 [string]$OutputFile,[string]$Model,[string]$Effort,[switch]$Capabilities,
 [ValidateRange(0,604800)][int]$TimeoutSeconds
)
$ErrorActionPreference='Stop'
$config=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'client-config.json') -Raw | ConvertFrom-Json
if($config.version -ne 1){throw 'Unsupported helper configuration'}
$actions=@($RequestFile,$Prompt,$Status.IsPresent,$Cancel.IsPresent,$SendFile,$FetchArtifact.IsPresent,$EchoArtifact.IsPresent,$Capabilities.IsPresent)|Where-Object{$_}
if(@($actions).Count -ne 1){throw 'Choose exactly one: RequestFile, Prompt, Status, Cancel, SendFile, FetchArtifact, EchoArtifact or Capabilities'}
if($GenerateImage -and !$Prompt){throw 'GenerateImage requires Prompt'}
if(($PSBoundParameters.ContainsKey('Model') -or $PSBoundParameters.ContainsKey('Effort')) -and !$Prompt){throw 'Model and Effort apply only to Prompt submissions'}
if($PSBoundParameters.ContainsKey('TimeoutSeconds') -and !$Prompt){throw 'TimeoutSeconds applies only to Prompt submissions'}
if($PSBoundParameters.ContainsKey('Model') -and $Model -cnotmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$'){throw 'Use a model ID from the host Capabilities catalog'}
if($PSBoundParameters.ContainsKey('Effort') -and $Effort -cnotmatch '^[a-z][a-z0-9_-]{0,31}$'){throw 'Use an effort value from the host Capabilities catalog'}
if(!$TaskId -and ($Prompt -or $Capabilities)){$TaskId=[guid]::NewGuid().ToString('N')}
if(!$RequestFile -and $TaskId -notmatch '^[a-f0-9]{32}$'){throw 'TaskId must be 32 lowercase hex characters; reuse the submitted task ID for status/files'}
function Invoke-Packet($request){
 $request.version=1;$request.id=[guid]::NewGuid().ToString('N');$request.taskId=$TaskId
 $temp=Join-Path $PSScriptRoot ('request-'+[guid]::NewGuid().ToString('N')+'.json')
 try{
  [IO.File]::WriteAllText($temp,($request|ConvertTo-Json -Depth 20 -Compress),[Text.UTF8Encoding]::new($false))
  $raw=& (Join-Path $PSScriptRoot 'task-client.ps1') -RequestFile $temp -TrialHome $config.trialHome -ReasonExe $config.reasonExe
  $result=($raw -join "`n")|ConvertFrom-Json
  if($result.version -ne 1 -or $result.id -ne $request.id){throw 'Authenticated response identity mismatch'}
  return $result
 }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Assert-Name([string]$Name){
 if($Name -notmatch '^[A-Za-z0-9][A-Za-z0-9._ -]{0,119}$' -or $Name.Contains('..') -or $Name.EndsWith('.') -or $Name.EndsWith(' ') -or $Name.Split('.')[0] -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$'){throw 'Unsafe artifact filename'}
}
function Assert-Plain([string]$Path){
 $item=Get-Item -LiteralPath $Path -Force
 while($item){if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Reparse/symlink paths are not accepted'};if($item -is [IO.FileInfo]){$item=$item.Directory}else{$item=$item.Parent}}
}
function Get-Digest([byte[]]$Bytes){
 $sha=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
}
if($RequestFile){
 if(!(Test-Path -LiteralPath $RequestFile -PathType Leaf)){throw 'Request JSON file not found'}
 $argsToClient=@{RequestFile=[IO.Path]::GetFullPath($RequestFile);TrialHome=$config.trialHome;ReasonExe=$config.reasonExe}
 if($OutputFile){$argsToClient.OutputFile=[IO.Path]::GetFullPath($OutputFile)}
 & (Join-Path $PSScriptRoot 'task-client.ps1') @argsToClient
 return
}
if($SendFile){
 $file=Get-Item -LiteralPath $SendFile -Force
 Assert-Plain $file.FullName;Assert-Name $file.Name
 if($file.PSIsContainer -or $file.Length -gt 1048576){throw 'Send one ordinary file of at most 1 MiB'}
 $bytes=[IO.File]::ReadAllBytes($file.FullName)
 if($bytes.Length -gt 1048576){throw 'File grew beyond 1 MiB'}
 $mime='application/octet-stream'
 if($bytes.Length -ge 8 -and [BitConverter]::ToString($bytes,0,8) -eq '89-50-4E-47-0D-0A-1A-0A'){$mime='image/png'}
 elseif($bytes.Length -ge 3 -and [BitConverter]::ToString($bytes,0,3) -eq 'FF-D8-FF'){$mime='image/jpeg'}
 elseif($bytes.Length -ge 12 -and [Text.Encoding]::ASCII.GetString($bytes,0,4) -eq 'RIFF' -and [Text.Encoding]::ASCII.GetString($bytes,8,4) -eq 'WEBP'){$mime='image/webp'}
 $transfer=[guid]::NewGuid().ToString('N');$chunks=[int][Math]::Ceiling($bytes.Length/24576.0)
 $manifest=@{type='artifact-manifest';version=1;transfer_id=$transfer;name=$file.Name;mime=$mime;size=$bytes.Length;sha256=(Get-Digest $bytes);chunks=$chunks;chunk_bytes=24576}
 $result=Invoke-Packet @{type='upload';artifactPacket=($manifest|ConvertTo-Json -Compress)}
 if($result.state -notin @('uploading','uploaded')){throw 'Manifest was not accepted; inspect the private response'}
 for($i=0;$i -lt $chunks;$i++){
  Start-Sleep -Milliseconds 1100
  $length=[Math]::Min(24576,$bytes.Length-$i*24576);$part=New-Object byte[] $length;[Array]::Copy($bytes,$i*24576,$part,0,$length)
  $packet=@{type='artifact-chunk';version=1;transfer_id=$transfer;index=$i;data=[Convert]::ToBase64String($part)}
  $result=Invoke-Packet @{type='upload';artifactPacket=($packet|ConvertTo-Json -Compress)}
  if($result.state -notin @('uploading','uploaded')){throw 'Chunk was not accepted; inspect the private response'}
 }
 if($result.state -ne 'uploaded' -or $result.artifact.sha256 -ne $manifest.sha256 -or $result.artifact.size -ne $bytes.Length){throw 'Final upload receipt did not match file hash/size'}
}elseif($FetchArtifact){
 Assert-Name $ArtifactName
 if(!$DestinationDirectory){throw 'Choose a private local DestinationDirectory'}
 $destination=[IO.Path]::GetFullPath($DestinationDirectory)
 if($destination.StartsWith('\\')){throw 'Use a local destination'}
 if(!(Test-Path -LiteralPath $destination -PathType Container)){throw 'Create your destination folder first'}
 Assert-Plain $destination
 $first=Invoke-Packet @{type='artifact';name=$ArtifactName;index=0}
 $manifest=$first.artifactPacket|ConvertFrom-Json
 if($manifest.type -ne 'artifact-manifest' -or $manifest.version -ne 1 -or $manifest.transfer_id -notmatch '^[a-f0-9]{32}$' -or $manifest.name -ne $ArtifactName -or $manifest.size -lt 0 -or $manifest.size -gt 1048576 -or $manifest.chunk_bytes -ne 24576 -or $manifest.chunks -ne [Math]::Ceiling($manifest.size/24576.0) -or $first.count -ne $manifest.chunks+1 -or $manifest.sha256 -notmatch '^[a-f0-9]{64}$'){throw 'Invalid bounded artifact manifest'}
 $memory=[IO.MemoryStream]::new()
 try{
  for($i=0;$i -lt $manifest.chunks;$i++){
   Start-Sleep -Milliseconds 1100
   $response=Invoke-Packet @{type='artifact';name=$ArtifactName;index=($i+1)}
   $part=$response.artifactPacket|ConvertFrom-Json
   if($response.index -ne $i+1 -or $response.count -ne $first.count -or $part.type -ne 'artifact-chunk' -or $part.version -ne 1 -or $part.transfer_id -ne $manifest.transfer_id -or $part.index -ne $i){throw 'Artifact chunk identity mismatch'}
   $bytes=[Convert]::FromBase64String($part.data)
   if($bytes.Length -ne [Math]::Min(24576,$manifest.size-$i*24576)){throw 'Artifact chunk size mismatch'}
   $memory.Write($bytes,0,$bytes.Length)
  }
  $bytes=$memory.ToArray()
 }finally{$memory.Dispose()}
 if($bytes.Length -ne $manifest.size -or (Get-Digest $bytes) -ne $manifest.sha256){throw 'Artifact size/hash mismatch; nothing saved'}
 $target=Join-Path $destination $ArtifactName
 $stream=[IO.File]::Open($target,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
 $result=[pscustomobject]@{version=1;state='downloaded';taskId=$TaskId;path=$target;size=$bytes.Length;sha256=$manifest.sha256}
}elseif($EchoArtifact){
 Assert-Name $ArtifactName
 $result=Invoke-Packet @{type='echo';name=$ArtifactName}
 if($result.task.state -ne 'artifact-echo-completed' -or $result.task.codexInvocations -ne 0){throw 'Expected zero-model file echo receipt absent'}
}elseif($Prompt){
 if([Text.Encoding]::UTF8.GetByteCount($Prompt) -gt 16384){throw 'Prompt must be at most 16 KiB'}
 $request=@{type='submit';mode='read-only';prompt=$Prompt}
 if($PSBoundParameters.ContainsKey('Model')){$request.model=$Model}
 if($PSBoundParameters.ContainsKey('Effort')){$request.effort=$Effort}
 if($PSBoundParameters.ContainsKey('TimeoutSeconds')){$request.timeoutSeconds=$TimeoutSeconds}
 if($GenerateImage){$request.operation='image'}
 $result=Invoke-Packet $request
}elseif($Capabilities){$result=Invoke-Packet @{type='capabilities'}
 if($result.state -ne 'capabilities' -or !$result.defaults -or $null -eq $result.models){throw 'Expected host capabilities receipt absent'}
}elseif($Status){$result=Invoke-Packet @{type='status'}}
elseif($Cancel){$result=Invoke-Packet @{type='cancel'}}
$json=$result|ConvertTo-Json -Depth 20 -Compress
if($OutputFile){[IO.File]::WriteAllText([IO.Path]::GetFullPath($OutputFile),$json,[Text.UTF8Encoding]::new($false))}
Write-Output $json
