# Read-only prerequisite checks. Never logs in, enrolls, changes policy or prints account metadata.
function Convert-TailscaleReadyState([string]$Json){
 try{$state=$Json|ConvertFrom-Json}catch{return $false}
 if($state.BackendState -ne 'Running' -or !$state.Self){return $false}
 foreach($address in @($state.TailscaleIPs)){
  $ip=$null
  if([Net.IPAddress]::TryParse([string]$address,[ref]$ip) -and $ip.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork){
   $bytes=$ip.GetAddressBytes()
   if($bytes[0] -eq 100 -and $bytes[1] -ge 64 -and $bytes[1] -le 127){return $true}
  }
 }
 return $false
}
function Get-TailscalePrerequisite {
 $candidates=@()
 if($env:ProgramFiles){$candidates+=Join-Path $env:ProgramFiles 'Tailscale/tailscale.exe'}
 if(${env:ProgramFiles(x86)}){$candidates+=Join-Path ${env:ProgramFiles(x86)} 'Tailscale/tailscale.exe'}
 $binary=$candidates|Where-Object{Test-Path -LiteralPath $_ -PathType Leaf}|Select-Object -First 1
 if(!$binary){return [pscustomobject]@{Installed=$false;Ready=$false;Download='https://tailscale.com/download/windows';Reason='Install Tailscale, then sign in to the same existing account as your host.'}}
 $info=New-Object Diagnostics.ProcessStartInfo
 $info.FileName=$binary;$info.Arguments='status --json';$info.UseShellExecute=$false;$info.CreateNoWindow=$true
 $info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
 $process=New-Object Diagnostics.Process;$process.StartInfo=$info
 try{
  [void]$process.Start();$output=$process.StandardOutput.ReadToEndAsync();$errorOutput=$process.StandardError.ReadToEndAsync()
  if(!$process.WaitForExit(5000)){$process.Kill();[void]$process.WaitForExit(5000);return [pscustomobject]@{Installed=$true;Ready=$false;Reason='Tailscale status timed out. Open Tailscale and check its connection.'}}
  if($process.ExitCode -ne 0 -or [Text.Encoding]::UTF8.GetByteCount($output.Result) -gt 1MB){return [pscustomobject]@{Installed=$true;Ready=$false;Reason='Open Tailscale and sign in to the same existing account as your host.'}}
  $ready=Convert-TailscaleReadyState $output.Result
  return [pscustomobject]@{Installed=$true;Ready=$ready;Reason=$(if($ready){'Tailscale is running. The actual host connection still needs its private capability test.'}else{'Open Tailscale and sign in to the same existing account as your host.'})}
 }catch{return [pscustomobject]@{Installed=$true;Ready=$false;Reason='Tailscale status could not be checked. Open the official app and confirm its connection.'}}
 finally{$process.Dispose()}
}
