function Get-PrivateFileHash([string]$Path){
 $stream=[IO.File]::OpenRead($Path);$sha=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose();$sha.Dispose()}
}
function Assert-PrivateConfig($Config){
 if(($Config.version -isnot [int] -and $Config.version -isnot [long]) -or $Config.endpoint -isnot [string] -or $Config.clientPerson -isnot [string] -or $Config.token -isnot [string]){throw 'Invalid private scalar types'}
 if($Config.version -ne 2 -or $Config.clientPerson -notmatch '^device-[a-f0-9]{8}$' -or $Config.token -cnotmatch '^[A-Za-z0-9_-]{43}$'){throw 'Invalid private device configuration'}
 $uri=$null
 if(![Uri]::TryCreate([string]$Config.endpoint,[UriKind]::Absolute,[ref]$uri)){throw 'Invalid private endpoint'}
 $ip=$null
 if($uri.Scheme -ne 'http' -or $uri.Port -ne 8771 -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne '/' -or ![Net.IPAddress]::TryParse($uri.Host,[ref]$ip) -or $ip.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork){throw 'Endpoint must be a numeric private Tailscale IPv4 address on port 8771'}
 $b=$ip.GetAddressBytes();if($b[0] -ne 100 -or $b[1] -lt 64 -or $b[1] -gt 127 -or $ip.ToString() -ne $uri.Host){throw 'Endpoint is outside the private Tailscale address range'}
}
function Invoke-PrivateHttp($Config,[string]$Method,[string]$Route,[string]$Body='{}',[string]$Upload,[string]$Download,[string]$Mime='application/json'){
 Assert-PrivateConfig $Config
 if($Route -notmatch '^/v1/(enroll|request|files/[a-f0-9]{32}/[A-Za-z0-9%._-]+)$'){throw 'Unsupported private route'}
 $request=[Net.HttpWebRequest]::Create($Config.endpoint.TrimEnd('/')+$Route)
 $request.Method=$Method;$request.Proxy=$null;$request.AllowAutoRedirect=$false;$request.Timeout=120000;$request.ReadWriteTimeout=120000;$request.KeepAlive=$false;$request.AllowWriteStreamBuffering=$false
 $request.Headers['Authorization']='Bearer '+$Config.token
 $input=$null;$response=$null;$out=$null;$temp=$null
 try{
  if($Upload){
   $input=[IO.File]::Open($Upload,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
   if($input.Length -gt 10MB){throw 'File exceeds 10 MiB'}
   $sha=[Security.Cryptography.SHA256]::Create();try{$digest=([BitConverter]::ToString($sha.ComputeHash($input))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()};$input.Position=0
   $request.ContentLength=$input.Length;$request.ContentType=$Mime;$request.Headers['X-Content-SHA256']=$digest
  }else{$bytes=[Text.Encoding]::UTF8.GetBytes($Body);if($bytes.Length -gt 65536){throw 'JSON request too large'};$request.ContentLength=if($Method -eq 'GET'){0}else{$bytes.Length};$request.ContentType='application/json'}
  if($Method -ne 'GET'){
   $out=$request.GetRequestStream()
   if($input){$buffer=New-Object byte[] 65536;$sent=0;while(($n=$input.Read($buffer,0,$buffer.Length)) -gt 0){$out.Write($buffer,0,$n);$sent+=$n;Write-Progress -Id 7 -Activity 'Sending private file' -Status "$sent / $($input.Length) bytes" -PercentComplete ([int](100*$sent/[Math]::Max(1,$input.Length)))}}else{$out.Write($bytes,0,$bytes.Length)}
   $out.Dispose();$out=$null
  }
  $response=$request.GetResponse()
  if([int]$response.StatusCode -ne 200){throw 'Private endpoint did not accept the operation'}
  $length=$response.ContentLength
  if($length -lt 0 -or $length -gt $(if($Download){10MB}else{65536})){throw 'Invalid bounded response size'}
  $stream=$response.GetResponseStream()
  if($Download){
   $hash=$response.Headers['X-Content-SHA256'];if($hash -cnotmatch '^[a-f0-9]{64}$'){throw 'Missing artifact digest'}
   $temp=$Download+'.partial-'+[guid]::NewGuid().ToString('N');$out=[IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
  }else{$out=[IO.MemoryStream]::new()}
  $buffer=New-Object byte[] 65536;$received=0
  while(($n=$stream.Read($buffer,0,$buffer.Length)) -gt 0){$received+=$n;if($received -gt $length){throw 'Response exceeded declared size'};$out.Write($buffer,0,$n);if($Download){Write-Progress -Id 7 -Activity 'Receiving private file' -Status "$received / $length bytes" -PercentComplete ([int](100*$received/[Math]::Max(1,$length)))}}
  if($received -ne $length){throw 'Incomplete response; nothing accepted'}
  if($Download){
   $out.Dispose();$out=$null
   if((Get-PrivateFileHash $temp) -ne $hash){throw 'Artifact digest mismatch; nothing saved'}
   [IO.File]::Move($temp,$Download);$temp=$null
   return [pscustomobject]@{version=2;state='downloaded';path=$Download;size=$length;sha256=$hash}
  }
  $json=[Text.Encoding]::UTF8.GetString($out.ToArray())
  $result=$json|ConvertFrom-Json
  if($Upload -and ($result.state -ne 'uploaded' -or $result.artifact.sha256 -ne $digest -or $result.artifact.size -ne $input.Length)){throw 'Upload receipt mismatch'}
  return $result
 }catch{throw 'Private transfer failed. Check both Tailscale connections and host readiness; no automatic retry was made.'}
 finally{if($input){$input.Dispose()};if($out){$out.Dispose()};if($response){$response.Dispose()};if($temp -and (Test-Path -LiteralPath $temp)){Remove-Item -LiteralPath $temp -Force};Write-Progress -Id 7 -Activity 'Private transfer' -Completed}
}
