param([string]$RequestFile,[string]$Prompt,[switch]$GenerateImage,[switch]$Status,[switch]$Cancel,[string]$TaskId,[string]$SendFile,[switch]$FetchArtifact,[switch]$EchoArtifact,[string]$ArtifactName='response.txt',[string]$DestinationDirectory,[string]$OutputFile)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Private-Transport.ps1')
$config=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'client-config.json') -Raw|ConvertFrom-Json
Assert-PrivateConfig $config
$actions=@($RequestFile,$Prompt,$Status.IsPresent,$Cancel.IsPresent,$SendFile,$FetchArtifact.IsPresent,$EchoArtifact.IsPresent)|Where-Object{$_}
if(@($actions).Count -ne 1){throw 'Choose exactly one helper action'}
if($GenerateImage -and !$Prompt){throw 'GenerateImage requires Prompt'}
if(!$TaskId -and $Prompt){$TaskId=[guid]::NewGuid().ToString('N')}
if(!$RequestFile -and $TaskId -notmatch '^[a-f0-9]{32}$'){throw 'TaskId must be 32 lowercase hexadecimal characters'}
function Assert-Name($Name){if($Name -notmatch '^[A-Za-z0-9][A-Za-z0-9._ -]{0,119}$' -or $Name.Contains('..') -or $Name.EndsWith('.') -or $Name.EndsWith(' ') -or $Name.Split('.')[0] -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$'){throw 'Unsafe artifact name'}}
function Assert-Plain($Path){$item=Get-Item -LiteralPath $Path -Force;while($item){if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse paths are not accepted'};if($item -is [IO.FileInfo]){$item=$item.Directory}else{$item=$item.Parent}}}
if($SendFile){
 $file=Get-Item -LiteralPath $SendFile -Force;Assert-Plain $file.FullName;Assert-Name $file.Name
 if($file.PSIsContainer -or $file.Length -gt 10MB){throw 'Send one ordinary file of at most 10 MiB'}
 $mime='application/octet-stream';$header=New-Object byte[] 12;$input=[IO.File]::OpenRead($file.FullName)
 try{$n=$input.Read($header,0,12)}finally{$input.Dispose()}
 if($n -ge 8 -and [BitConverter]::ToString($header,0,8) -eq '89-50-4E-47-0D-0A-1A-0A'){$mime='image/png'}elseif($n -ge 3 -and [BitConverter]::ToString($header,0,3) -eq 'FF-D8-FF'){$mime='image/jpeg'}elseif($n -ge 12 -and [Text.Encoding]::ASCII.GetString($header,0,4) -eq 'RIFF' -and [Text.Encoding]::ASCII.GetString($header,8,4) -eq 'WEBP'){$mime='image/webp'}
 $result=Invoke-PrivateHttp $config PUT ('/v1/files/'+$TaskId+'/'+[Uri]::EscapeDataString($file.Name)) -Upload $file.FullName -Mime $mime
}elseif($FetchArtifact){
 Assert-Name $ArtifactName
 if(!$DestinationDirectory){throw 'Choose an existing local destination directory'}
 $dest=[IO.Path]::GetFullPath($DestinationDirectory)
 if($dest.StartsWith('\\') -or !(Test-Path -LiteralPath $dest -PathType Container)){throw 'Choose an existing local directory'}
 Assert-Plain $dest;$target=Join-Path $dest $ArtifactName
 if(Test-Path -LiteralPath $target){throw 'Destination exists; existing files are never overwritten'}
 $result=Invoke-PrivateHttp $config GET ('/v1/files/'+$TaskId+'/'+[Uri]::EscapeDataString($ArtifactName)) -Download $target
}else{
 if($RequestFile){if((Get-Item -LiteralPath $RequestFile).Length -gt 65536){throw 'Request file too large'};$request=Get-Content -LiteralPath $RequestFile -Raw|ConvertFrom-Json}else{
  $request=@{version=1;id=[guid]::NewGuid().ToString('N');taskId=$TaskId;type='status'}
  if($Prompt){if([Text.Encoding]::UTF8.GetByteCount($Prompt) -gt 16384){throw 'Prompt exceeds 16 KiB'};$request.type='submit';$request.prompt=$Prompt;$request.mode='read-only';if($GenerateImage){$request.operation='image'}}elseif($Cancel){$request.type='cancel'}elseif($EchoArtifact){Assert-Name $ArtifactName;$request.type='echo';$request.name=$ArtifactName}
 }
 if($request.version -ne 1 -or $request.id -notmatch '^[a-f0-9]{32}$' -or $request.taskId -notmatch '^[a-f0-9]{32}$' -or $request.type -notin @('submit','status','cancel','echo')){throw 'Invalid private request envelope'}
 $result=Invoke-PrivateHttp $config POST '/v1/request' -Body ($request|ConvertTo-Json -Depth 20 -Compress)
 if($result.version -ne 1 -or $result.id -ne $request.id){throw 'Private response identity mismatch'}
}
$json=$result|ConvertTo-Json -Depth 20 -Compress
if($OutputFile){[IO.File]::WriteAllText([IO.Path]::GetFullPath($OutputFile),$json,[Text.UTF8Encoding]::new($false))}
Write-Output $json
