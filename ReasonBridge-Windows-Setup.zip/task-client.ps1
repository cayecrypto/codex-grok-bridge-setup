param([Parameter(Mandatory=$true)][string]$RequestFile,[Parameter(Mandatory=$true)][string]$TrialHome,[Parameter(Mandatory=$true)][string]$ReasonExe,[string]$OutputFile)
$ErrorActionPreference='Stop'
$req=Get-Content -LiteralPath $RequestFile -Raw|ConvertFrom-Json
if($req.version -ne 1 -or $req.id -notmatch '^[a-f0-9]{32}$' -or $req.taskId -notmatch '^[a-f0-9]{32}$' -or $req.type -notin @('submit','status','cancel','artifact','upload','echo')){throw 'Invalid request envelope'}
if((Get-FileHash -LiteralPath $ReasonExe).Hash.ToLowerInvariant() -ne '849a3d68bf67c3eab8a77a79f0376f343945683a8de0c8ed3297e096166838c4'){throw 'Pinned binary mismatch'}
$ClientPerson='remote-laptop';$TargetPeer='codex-host/worker'
$identityPath=Join-Path $TrialHome 'bridge-client.json'
if(Test-Path -LiteralPath $identityPath){$identity=Get-Content -LiteralPath $identityPath -Raw|ConvertFrom-Json;if($identity -isnot [pscustomobject] -or (@($identity.PSObject.Properties.Name|Sort-Object) -join ',') -ne 'clientPerson,targetPeer,version' -or $identity.version -isnot [int] -or $identity.clientPerson -isnot [string] -or $identity.targetPeer -isnot [string] -or $identity.version -ne 1 -or $identity.clientPerson -notmatch '^(device-[a-f0-9]{8}|remote-laptop)$' -or $identity.targetPeer -ne 'codex-host/worker'){throw 'Invalid client identity'};$ClientPerson=[string]$identity.clientPerson;$TargetPeer=[string]$identity.targetPeer}
$cfg=[IO.File]::ReadAllText((Join-Path $TrialHome 'state/config.toml'))
foreach($key in @('share_paths','share_unmanaged','lan','tray','reason','auto_update')){if(([regex]::Matches($cfg,('(?m)^'+$key+'\s*=\s*false\s*$'))).Count -ne 1){throw 'Isolated configuration required'}}
if($cfg -notmatch ('(?m)^person\s*=\s*"'+[regex]::Escape($ClientPerson)+'"\s*$') -or $cfg -notmatch '(?ms)^\[inbound\]\s*\r?\n.*?^default\s*=\s*"hold"\s*$'){throw 'Wrong paired identity/policy'}
$saved=@{};$children=New-Object 'System.Collections.Generic.List[System.Diagnostics.Process]'
foreach($key in @('REASON_NETWORK_HOME','USERPROFILE','HOME','TEMP','TMP')){$saved[$key]=[Environment]::GetEnvironmentVariable($key,'Process')}
function Start-Reason([string]$ArgsText,[string]$InputText=''){
 if($ArgsText -ne 'daemon' -and $daemon.HasExited){throw 'Owned daemon ended; no autostart'}
 $i=New-Object Diagnostics.ProcessStartInfo;$i.FileName=$ReasonExe;$i.Arguments=$ArgsText;$i.WorkingDirectory=Join-Path $TrialHome 'work';$i.UseShellExecute=$false;$i.CreateNoWindow=$true
 $i.RedirectStandardInput=$true;$i.RedirectStandardOutput=$true;$i.RedirectStandardError=$true;$i.StandardOutputEncoding=[Text.Encoding]::UTF8;$i.StandardErrorEncoding=[Text.Encoding]::UTF8
 $p=New-Object Diagnostics.Process;$p.StartInfo=$i;[void]$p.Start();$children.Add($p)
 if($InputText){$p.StandardInput.Write($InputText)};$p.StandardInput.Close()
 return $p
}
function Run-Reason([string]$ArgsText,[string]$InputText=''){
 $p=Start-Reason $ArgsText $InputText;$out=$p.StandardOutput.ReadToEndAsync();$err=$p.StandardError.ReadToEndAsync()
 if(!$p.WaitForExit(8000)){throw 'Reason command timed out'};if($p.ExitCode -ne 0){throw 'Reason command failed'};return $out.Result
}
function Decode-Packet([string]$Body){
 if($Body -notmatch '^RNB1:[A-Za-z0-9+/=]+$' -or $Body.Length -gt 64000){throw 'Invalid response packet'}
 $v=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Body.Substring(5)))|ConvertFrom-Json
 if($v.version -ne 1 -or $v.id -ne $req.id){throw 'Response request identity mismatch'};return $v
}
try{
 $env:REASON_NETWORK_HOME=Join-Path $TrialHome 'state';$env:USERPROFILE=Join-Path $TrialHome 'profile';$env:HOME=$env:USERPROFILE;$env:TEMP=Join-Path $TrialHome 'temp';$env:TMP=$env:TEMP
 $daemon=Start-Reason 'daemon';$do=$daemon.StandardOutput.ReadToEndAsync();$de=$daemon.StandardError.ReadToEndAsync();Start-Sleep -Milliseconds 800
 if($daemon.HasExited){throw 'Owned daemon failed; do not reuse another daemon'}
 $listen=Start-Reason 'listen --as client --wait 30';$lo=$listen.StandardOutput.ReadToEndAsync();$le=$listen.StandardError.ReadToEndAsync();Start-Sleep -Milliseconds 400
 $body='RNB1:'+[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($req|ConvertTo-Json -Depth 10 -Compress)))
 if($body.Length -gt 64000){throw 'Request too large'}
 $null=Run-Reason 'send codex-host/worker - --from client' $body
 $deadline=[DateTime]::UtcNow.AddSeconds(30)
 while(!$listen.HasExited -and [DateTime]::UtcNow -lt $deadline){
  $held=Run-Reason 'held'
  if($held.Trim() -ne 'Nothing held.'){
   $m=[regex]::Match($held,'\A\u2500\u2500 codex-host/worker(?: \([^\r\n]*\))? \u00b7 [^\r\n]+ ago \u00b7 ([A-Z0-9]{26})\r?\n(RNB1:[A-Za-z0-9+/=]+)\r?\n\r?\n`reason-network approve <id>` delivers, `reason-network reject <id>` drops \(or --all\)\.\r?\n\z')
   if(!$m.Success){throw 'Unexpected held record; no approval'};$null=Decode-Packet $m.Groups[2].Value;$null=Run-Reason ('approve '+$m.Groups[1].Value);break
  };Start-Sleep -Milliseconds 1000
 }
 if(!$listen.WaitForExit(5000)){throw 'Response timed out'}
 $m=[regex]::Match($lo.Result,'\A<reason-message from="codex-host/worker"[^>]*>\r?\n(RNB1:[A-Za-z0-9+/=]+)\r?\n</reason-message>\s*\z')
 if(!$m.Success){throw 'Expected paired response absent'};$result=Decode-Packet $m.Groups[1].Value;$json=$result|ConvertTo-Json -Depth 20 -Compress
 if($OutputFile){[IO.File]::WriteAllText($OutputFile,$json)};Write-Output $json
}finally{
 foreach($p in $children){if(!$p.HasExited){$p.Kill()};if(!$p.WaitForExit(5000)){throw 'Owned child exit unconfirmed'}}
 foreach($key in $saved.Keys){[Environment]::SetEnvironmentVariable($key,$saved[$key],'Process')}
}
